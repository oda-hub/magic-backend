#!/bin/sh
touch magic_19e_sed_fig1_target_all.ecsv 
touch magic_19e_sed_fig1_target01.ecsv 
touch magic_19e_sed_fig1_target04.ecsv 
touch magic_19e_sed_fig1_target07.ecsv 
touch magic_19e_sed_fig1_target08.ecsv 
touch magic_19e_sed_fig1_target09.ecsv 
touch magic_19e_lc1_fig2_target_all.ecsv 
touch magic_19e_lc1_fig2_target01.ecsv 
touch magic_19e_lc1_fig2_target02.ecsv 
touch magic_19e_lc1_fig2_target03.ecsv 
touch magic_19e_lc1_fig2_target04.ecsv 
touch magic_19e_lc1_fig2_target05.ecsv 
touch magic_19e_lc1_fig2_target06.ecsv 
touch magic_19e_lc1_fig2_target07.ecsv 
touch magic_19e_lc1_fig2_target08.ecsv 
touch magic_19e_lc1_fig2_target09.ecsv 
touch magic_19e_lc1_fig2_target010.ecsv 
touch magic_19e_lc1_fig2_target011.ecsv 
touch magic_19e_sed_fig3_mwl_target_all.ecsv 
touch magic_19e_sed_fig3_mwl_target11.ecsv 
touch magic_19e_sed_fig3_mwl_target07.ecsv 
touch magic_19e_sed_fig3_mwl_target04.ecsv 
touch magic_19e_sed_fig3_mwl_target08.ecsv 
touch magic_19e_sed_fig3_mwl_target09.ecsv 
touch magic_19e_sed_fig3_mwl_target01.ecsv 
touch magic_19e_sed_fig3_nofit_target_all.ecsv 
touch magic_19e_sed_fig3_nofit_target11.ecsv 
touch magic_19e_sed_fig3_nofit_target07.ecsv 
touch magic_19e_sed_fig3_nofit_target04.ecsv 
touch magic_19e_sed_fig3_nofit_target08.ecsv 
touch magic_19e_sed_fig3_nofit_target09.ecsv 
touch magic_19e_sed_fig3_nofit_target01.ecsv 
touch magic_19e_sed_fig4_mwl_target_all.ecsv 
touch magic_19e_sed_fig4_mwl_target05.ecsv 
touch magic_19e_sed_fig4_mwl_target03.ecsv 
touch magic_19e_sed_fig4_mwl_target10.ecsv 
touch magic_19e_sed_fig4_mwl_target02.ecsv 
touch magic_19e_sed_fig4_nofit_target_all.ecsv 
touch magic_19e_sed_fig4_nofit_target05.ecsv 
touch magic_19e_sed_fig4_nofit_target03.ecsv 
touch magic_19e_sed_fig4_nofit_target10.ecsv 
touch magic_19e_sed_fig4_nofit_target02.ecsv 
touch magic_19e_sed1_fig1_target01_noebl.ecsv 
touch magic_19e_sed1_fig1_target04_noebl.ecsv 
touch magic_19e_sed1_fig1_target07_noebl.ecsv 
touch magic_19e_sed1_fig1_noebl_target08.ecsv 
touch magic_19e_sed1_fig1_noebl_target09.ecsv 

 magic_19e_sed_fig3_model_target_all.ecsv 
 magic_19e_sed_fig3_model_target11.ecsv 
 magic_19e_sed_fig3_model_target07.ecsv 
 magic_19e_sed_fig3_model_target04.ecsv 
 magic_19e_sed_fig3_model_target08.ecsv 
 magic_19e_sed_fig3_model_target09.ecsv 
 magic_19e_sed_fig3_model_target01.ecsv 

 magic_19e_sed_fig4_model_target_all.ecsv 
 magic_19e_sed_fig4_model_target05.ecsv 
 magic_19e_sed_fig4_model_target03.ecsv 
 magic_19e_sed_fig4_model_target10.ecsv 
 magic_19e_sed_fig4_model_target02.ecsv 
Comments: 
              
